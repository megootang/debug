#####!# /system/bin/sh

CURRENT_PATH=`pwd`
TEST_PRJ_LOG="$CURRENT_PATH/fio.log"

stop
echo "stop android framework"
sleep 1

function main(){
	fio $CURRENT_PATH/jobs.txt > $CURRENT_PATH/total_result.txt 2>&1
	echo "fio test end!"
	exit
}

main
